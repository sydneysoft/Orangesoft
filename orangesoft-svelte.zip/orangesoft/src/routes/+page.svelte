<script>
  import { onMount } from 'svelte';
  import { lang, tr } from '$lib/i18n.js';

  let scrolled = false;
  let mx = 0, my = 0, rx = 0, ry = 0;
  let animFrame;

  const stack = ['JavaScript','Python','MongoDB','Firebase','MySQL','Node.js','React','FastAPI','WordPress','Shopify','Telegram Bot API','WhatsApp Business API','SvelteKit','Next.js','TypeScript','Docker','PostgreSQL','Supabase','GraphQL','Stripe'];

  function setLang(l) {
    lang.set(l);
    document.documentElement.lang = l;
  }

  onMount(() => {
    // scroll nav
    const onScroll = () => scrolled = window.scrollY > 40;
    window.addEventListener('scroll', onScroll);

    // cursor
    const dot  = document.getElementById('cur-dot');
    const ring = document.getElementById('cur-ring');
    document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });
    function animCursor() {
      if (dot)  { dot.style.left = mx+'px';  dot.style.top = my+'px'; }
      rx += (mx-rx)*0.12; ry += (my-ry)*0.12;
      if (ring) { ring.style.left = rx+'px'; ring.style.top = ry+'px'; }
      animFrame = requestAnimationFrame(animCursor);
    }
    animCursor();

    // reveal
    const els = document.querySelectorAll('.reveal');
    const obs = new IntersectionObserver(entries => {
      entries.forEach((e,i) => {
        if (e.isIntersecting) {
          e.target.style.transitionDelay = (i%3)*0.1+'s';
          e.target.classList.add('visible');
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.1 });
    els.forEach(el => obs.observe(el));

    return () => {
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(animFrame);
    };
  });
</script>

<svelte:head>
  <title>OrangeSoft — {$tr.nav_services} & Apps | Poland</title>
</svelte:head>

<!-- Custom cursor -->
<div id="cur-dot"  class="cur-dot"></div>
<div id="cur-ring" class="cur-ring"></div>

<!-- NAV -->
<nav class:scrolled>
  <a href="#" class="logo">Orange<span>Soft</span></a>
  <div class="nav-links">
    <a href="#services">{$tr.nav_services}</a>
    <a href="#process">{$tr.nav_process}</a>
    <a href="#pricing">{$tr.nav_pricing}</a>
    <a href="#team">{$tr.nav_team}</a>
    <a href="#contact" class="nav-cta">{$tr.nav_cta}</a>
    <div class="lang-switch">
      <button class:active={$lang==='pl'} on:click={() => setLang('pl')}>PL</button>
      <button class:active={$lang==='en'} on:click={() => setLang('en')}>EN</button>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <p class="hero-tag">{$tr.hero_tag}</p>
  <h1 class="hero-title">
    {$tr.hero_title_1}<br>
    {$tr.hero_title_2}<br>
    <em>{$tr.hero_title_3}</em>
  </h1>
  <p class="hero-sub">{$tr.hero_sub}</p>
  <div class="hero-actions">
    <a href="#contact" class="btn-primary">{$tr.hero_cta}</a>
    <a href="#services" class="btn-ghost">
      {$tr.hero_ghost}
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </a>
  </div>
  <div class="hero-counter">
    <div class="num">140+</div>
    <p>{$tr.hero_counter}</p>
  </div>
</section>

<!-- MARQUEE -->
<div class="marquee-wrap">
  <div class="marquee-track">
    {#each [1,2] as _}
      <div class="marquee-row">
        {#each ['Strony internetowe','Aplikacje mobilne','WordPress','Shopify','Boty Telegram','Boty WhatsApp','E-commerce','UX/UI Design','SaaS'] as item}
          <span class="marquee-item">{item}</span><span class="dot"></span>
        {/each}
      </div>
    {/each}
  </div>
</div>

<!-- SERVICES -->
<section class="services" id="services">
  <div class="services-header reveal">
    <div>
      <p class="section-label">{$tr.s_label}</p>
      <h2 class="section-title">{$tr.s_title_1}<br>{$tr.s_title_2}</h2>
    </div>
    <p class="services-desc">{$tr.s_desc}</p>
  </div>
  <div class="services-grid">
    {#each $tr.services as svc}
      <div class="service-card reveal">
        <div class="service-num">{svc.num}</div>
        <h3>{svc.title}</h3>
        <p>{svc.desc}</p>
        <div class="service-arrow">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 12L12 2M12 2H5M12 2v7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      </div>
    {/each}
  </div>
</section>

<!-- PROCESS -->
<section class="process" id="process">
  <div class="reveal">
    <p class="section-label">{$tr.p_label}</p>
    <h2 class="section-title">{$tr.p_title_1}<br>{$tr.p_title_2}</h2>
  </div>
  <div class="process-steps">
    {#each $tr.steps as step}
      <div class="step reveal">
        <div class="step-num">{step.num}</div>
        <h3>{step.title}</h3>
        <p>{step.desc}</p>
      </div>
    {/each}
  </div>
</section>

<!-- STACK -->
<section class="stack-section" id="stack">
  <div class="reveal">
    <p class="section-label">{$tr.stack_label}</p>
    <h2 class="section-title">{$tr.stack_title}</h2>
  </div>
  <div class="stack-grid reveal">
    {#each stack as tech}
      <div class="stack-item">{tech}</div>
    {/each}
  </div>
</section>

<!-- DEVELOPER -->
<section class="developer" id="team">
  <div class="reveal">
    <p class="section-label">{$tr.dev_label}</p>
    <h2 class="section-title">{$tr.dev_section_title}</h2>
  </div>
  <div class="dev-layout">
    <div class="dev-photo-wrap reveal">
      <div class="dev-photo-frame">
        <img src="/mijail.jpg" alt="Mijail Quesada" />
      </div>
      <div class="dev-accent-bar"></div>
      <div class="dev-accent-bar2"></div>
      <div class="dev-badge">
        <div class="yrs">10+</div>
        <p>{$tr.dev_stat1}</p>
      </div>
    </div>
    <div class="dev-info reveal">
      <h3 class="dev-name">Mijail<br>Quesada</h3>
      <p class="dev-role">{$tr.dev_role}</p>
      <p class="dev-bio">{$tr.dev_bio}</p>
      <p class="dev-stack-title">{$tr.dev_stack_label}</p>
      <div class="dev-skills">
        {#each ['JavaScript','Python','MongoDB','Firebase','MySQL','Node.js','React','FastAPI','WordPress','Shopify'] as skill}
          <div class="dev-skill"><span class="skill-dot"></span>{skill}</div>
        {/each}
      </div>
      <div class="dev-stats">
        <div class="dev-stat"><div class="val">10<span>+</span></div><div class="lbl">{$tr.dev_stat1}</div></div>
        <div class="dev-stat"><div class="val">140<span>+</span></div><div class="lbl">{$tr.dev_stat2}</div></div>
        <div class="dev-stat"><div class="val">10<span>+</span></div><div class="lbl">{$tr.dev_stat3}</div></div>
      </div>
    </div>
  </div>
</section>

<!-- PRICING -->
<section class="pricing" id="pricing">
  <div class="reveal">
    <p class="section-label">{$tr.pr_label}</p>
    <h2 class="section-title">{$tr.pr_title}</h2>
  </div>
  <div class="pricing-grid">
    {#each $tr.pricing as plan}
      <div class="plan reveal" class:featured={plan.featured}>
        {#if plan.featured}<div class="plan-badge">{$tr.pr_popular}</div>{/if}
        <p class="plan-name">{plan.name}</p>
        <div class="plan-price">{plan.price}</div>
        <p class="plan-desc">{plan.desc}</p>
        <ul class="plan-features">
          {#each plan.features as f}<li>{f}</li>{/each}
        </ul>
        <a href="#contact" class="plan-btn">{plan.featured ? $tr.pr_btn2 : $tr.pr_btn}</a>
      </div>
    {/each}
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials">
  <div class="reveal">
    <p class="section-label">{$tr.t_label}</p>
    <h2 class="section-title">{$tr.t_title_1}<br>{$tr.t_title_2}</h2>
  </div>
  <div class="testi-grid">
    {#each $tr.testimonials as t}
      <div class="testi-card reveal">
        <div class="testi-quote">"</div>
        <p class="testi-text">{t.text}</p>
        <div class="testi-author">
          <div class="testi-avatar" style="background:{t.color}">{t.initials}</div>
          <div>
            <div class="testi-name">{t.name}</div>
            <div class="testi-role">{t.role}</div>
          </div>
        </div>
      </div>
    {/each}
  </div>
</section>

<!-- CTA -->
<section class="cta-section" id="contact">
  <h2 class="cta-title">{$tr.cta_title_1}<br>{$tr.cta_title_2}</h2>
  <p>{$tr.cta_sub}</p>
  <a href="mailto:hello@orangesoft.pl" class="btn-white">{$tr.cta_btn}</a>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-top">
    <div class="footer-brand">
      <a href="#" class="logo">Orange<span>Soft</span></a>
      <p>{$tr.ft_desc}</p>
    </div>
    <div class="footer-cols">
      <div class="footer-links">
        <h4>{$tr.ft_services}</h4>
        <ul>{#each $tr.ft_links_services as l}<li><a href="#services">{l}</a></li>{/each}</ul>
      </div>
      <div class="footer-links">
        <h4>{$tr.ft_company}</h4>
        <ul>{#each $tr.ft_links_company as l}<li><a href="#">{l}</a></li>{/each}</ul>
      </div>
      <div class="footer-links">
        <h4>{$tr.ft_contact}</h4>
        <ul>
          <li><a href="mailto:hello@orangesoft.pl">hello@orangesoft.pl</a></li>
          <li><a href="tel:+48221234567">+48 22 123 45 67</a></li>
          <li><a href="#">LinkedIn</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>{$tr.ft_copy}</p>
    <div class="footer-flag">🇵🇱 {$tr.ft_flag}</div>
  </div>
</footer>

<style>
  :global(*, *::before, *::after) { box-sizing: border-box; margin: 0; padding: 0; }
  :global(:root) {
    --black: #0a0a0a; --white: #f5f2ec; --cream: #ede9df;
    --accent: #e84b2a; --accent2: #f4a522; --mid: #1c1c1c;
    --border: rgba(255,255,255,0.08);
  }
  :global(html) { scroll-behavior: smooth; }
  :global(body) {
    background: var(--black); color: var(--white);
    font-family: 'DM Sans', sans-serif; font-size: 17px;
    line-height: 1.6; overflow-x: hidden; cursor: none;
  }
  :global(a) { text-decoration: none; }

  /* CURSOR */
  .cur-dot {
    position: fixed; width: 12px; height: 12px; background: var(--accent);
    border-radius: 50%; pointer-events: none; z-index: 9999;
    transform: translate(-50%,-50%); transition: opacity .2s;
  }
  .cur-ring {
    position: fixed; width: 40px; height: 40px;
    border: 1.5px solid var(--accent); border-radius: 50%;
    pointer-events: none; z-index: 9998;
    transform: translate(-50%,-50%); opacity: 0.5;
  }

  /* NAV */
  nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    display: flex; align-items: center; justify-content: space-between;
    padding: 24px 48px; border-bottom: 1px solid transparent;
    transition: border-color .4s, background .4s;
  }
  nav.scrolled { border-color: var(--border); background: rgba(10,10,10,0.85); backdrop-filter: blur(16px); }
  .logo { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 22px; letter-spacing: -.5px; color: var(--white); }
  .logo span { color: var(--accent); }
  .nav-links { display: flex; gap: 32px; align-items: center; }
  .nav-links a { color: rgba(245,242,236,.6); font-size: 14px; letter-spacing: .5px; transition: color .2s; }
  .nav-links a:hover { color: var(--white); }
  .nav-cta { background: var(--accent) !important; color: var(--white) !important; padding: 10px 22px; border-radius: 2px; font-weight: 500; }
  .nav-cta:hover { background: #c93d20 !important; }

  /* LANG */
  .lang-switch { display: flex; border: 1px solid rgba(255,255,255,.15); border-radius: 2px; overflow: hidden; }
  .lang-switch button {
    background: transparent; border: none; color: rgba(245,242,236,.45);
    font-family: 'Syne', sans-serif; font-size: 12px; font-weight: 700;
    letter-spacing: 1.5px; padding: 7px 12px; cursor: pointer; transition: background .2s, color .2s;
  }
  .lang-switch button.active { background: var(--accent); color: var(--white); }
  .lang-switch button:hover:not(.active) { color: var(--white); background: rgba(255,255,255,.07); }

  /* HERO */
  .hero {
    min-height: 100vh; display: flex; flex-direction: column;
    justify-content: flex-end; padding: 0 48px 80px; position: relative; overflow: hidden;
  }
  .hero-bg {
    position: absolute; inset: 0;
    background: radial-gradient(ellipse 60% 50% at 80% 30%, rgba(232,75,42,.12) 0%, transparent 70%),
                radial-gradient(ellipse 40% 40% at 10% 80%, rgba(244,165,34,.08) 0%, transparent 60%);
  }
  .hero-grid {
    position: absolute; inset: 0;
    background-image: linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),
                      linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px);
    background-size: 80px 80px;
    mask-image: linear-gradient(to bottom,transparent 0%,black 30%,black 70%,transparent 100%);
  }
  .hero-tag { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: var(--accent); margin-bottom: 28px; animation: fadeUp .8s .2s both; }
  .hero-title { font-family: 'Syne',sans-serif; font-size: clamp(54px,8vw,130px); font-weight: 800; line-height: .92; letter-spacing: -3px; max-width: 900px; animation: fadeUp .9s .4s both; }
  .hero-title em { font-style: normal; color: var(--accent); position: relative; }
  .hero-title em::after { content:''; position: absolute; bottom: 8px; left:0; right:0; height: 4px; background: var(--accent); opacity: .3; }
  .hero-sub { margin-top: 40px; max-width: 440px; color: rgba(245,242,236,.55); font-size: 16px; line-height: 1.7; animation: fadeUp .9s .6s both; }
  .hero-actions { margin-top: 48px; display: flex; gap: 16px; align-items: center; animation: fadeUp .9s .8s both; }
  .btn-primary { background: var(--accent); color: var(--white); padding: 16px 36px; font-family: 'Syne',sans-serif; font-weight: 700; font-size: 14px; letter-spacing: 1px; text-transform: uppercase; border-radius: 2px; transition: background .2s, transform .2s; display: inline-block; }
  .btn-primary:hover { background: #c93d20; transform: translateY(-2px); }
  .btn-ghost { color: rgba(245,242,236,.6); font-size: 14px; display: flex; align-items: center; gap: 8px; transition: color .2s; }
  .btn-ghost:hover { color: var(--white); }
  .hero-counter { position: absolute; right: 48px; bottom: 80px; text-align: right; animation: fadeUp .9s 1s both; }
  .hero-counter .num { font-family: 'Syne',sans-serif; font-size: 64px; font-weight: 800; line-height:1; color: transparent; -webkit-text-stroke: 1px rgba(245,242,236,.15); }
  .hero-counter p { font-size: 12px; letter-spacing: 2px; text-transform: uppercase; color: rgba(245,242,236,.3); margin-top: 4px; }

  /* MARQUEE */
  .marquee-wrap { border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); overflow: hidden; padding: 20px 0; background: var(--mid); }
  .marquee-track { display: flex; width: max-content; animation: marquee 30s linear infinite; }
  .marquee-row { display: flex; gap: 0; align-items: center; }
  .marquee-item { font-family: 'Syne',sans-serif; font-size: 13px; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; color: rgba(245,242,236,.25); white-space: nowrap; padding: 0 30px; }
  .dot { width:6px; height:6px; border-radius:50%; background:var(--accent); opacity:.6; flex-shrink:0; display:inline-block; }

  /* SECTIONS */
  section { padding: 120px 48px; }
  .section-label { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: var(--accent); margin-bottom: 20px; }
  .section-title { font-family: 'Syne',sans-serif; font-size: clamp(36px,4vw,64px); font-weight: 800; line-height: 1.05; letter-spacing: -1.5px; }

  /* SERVICES */
  .services { background: var(--black); }
  .services-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 80px; gap: 40px; }
  .services-desc { max-width: 340px; color: rgba(245,242,236,.5); font-size: 15px; line-height: 1.7; flex-shrink: 0; }
  .services-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 2px; }
  .service-card { background: var(--mid); padding: 48px 40px; border: 1px solid var(--border); position: relative; overflow: hidden; transition: background .3s; }
  .service-card::before { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(232,75,42,.08) 0%,transparent 60%); opacity:0; transition:opacity .3s; }
  .service-card:hover { background: #222; }
  .service-card:hover::before { opacity:1; }
  .service-num { font-family:'Syne',sans-serif; font-size:12px; font-weight:700; letter-spacing:2px; color:var(--accent); margin-bottom:40px; }
  .service-card h3 { font-family:'Syne',sans-serif; font-size:22px; font-weight:700; margin-bottom:16px; }
  .service-card p { color:rgba(245,242,236,.45); font-size:14px; line-height:1.7; }
  .service-arrow { position:absolute; bottom:40px; right:40px; width:36px; height:36px; border:1px solid rgba(255,255,255,.1); border-radius:50%; display:flex; align-items:center; justify-content:center; color:rgba(245,242,236,.3); transition:border-color .2s,color .2s,transform .2s; }
  .service-card:hover .service-arrow { border-color:var(--accent); color:var(--accent); transform:rotate(45deg); }

  /* PROCESS */
  .process { background: var(--cream); color: var(--black); }
  .process .section-label { color: var(--accent); }
  .process .section-title { color: var(--black); }
  .process-steps { margin-top:80px; display:grid; grid-template-columns:repeat(4,1fr); gap:2px; }
  .step { padding:48px 32px; background:white; border-top:3px solid transparent; transition:border-color .2s; }
  .step:hover { border-color: var(--accent); }
  .step-num { font-family:'Syne',sans-serif; font-size:72px; font-weight:800; line-height:1; color:#e8e4da; margin-bottom:32px; }
  .step h3 { font-family:'Syne',sans-serif; font-size:18px; font-weight:700; color:var(--black); margin-bottom:12px; }
  .step p { font-size:14px; color:#666; line-height:1.7; }

  /* STACK */
  .stack-section { background: var(--mid); }
  .stack-grid { margin-top:64px; display:flex; flex-wrap:wrap; gap:2px; }
  .stack-item { background:rgba(255,255,255,.04); border:1px solid var(--border); padding:20px 32px; font-family:'Syne',sans-serif; font-size:14px; font-weight:700; color:rgba(245,242,236,.4); letter-spacing:1px; transition:background .2s,color .2s; }
  .stack-item:hover { background:var(--accent); color:var(--white); border-color:var(--accent); }

  /* DEVELOPER */
  .developer { background: var(--cream); color: var(--black); overflow: hidden; }
  .developer .section-label { color: var(--accent); }
  .developer .section-title { color: var(--black); }
  .dev-layout { margin-top:72px; display:grid; grid-template-columns:400px 1fr; gap:80px; align-items:center; }
  .dev-photo-wrap { position:relative; }
  .dev-photo-frame { position:relative; width:100%; aspect-ratio:3/4; overflow:hidden; background:#d5d0c7; }
  .dev-photo-frame img { width:100%; height:100%; object-fit:cover; object-position:center top; display:block; filter:grayscale(15%); transition:filter .4s; }
  .dev-photo-frame:hover img { filter:grayscale(0%); }
  .dev-accent-bar { position:absolute; top:24px; right:-24px; width:6px; bottom:-24px; background:var(--accent); }
  .dev-accent-bar2 { position:absolute; bottom:-24px; left:0; right:-24px; height:6px; background:var(--accent); }
  .dev-badge { position:absolute; bottom:28px; left:-20px; background:var(--black); color:var(--white); padding:14px 20px; font-family:'Syne',sans-serif; }
  .dev-badge .yrs { font-size:36px; font-weight:800; line-height:1; color:var(--accent); }
  .dev-badge p { font-size:11px; letter-spacing:2px; text-transform:uppercase; opacity:.6; margin-top:2px; }
  .dev-name { font-family:'Syne',sans-serif; font-size:clamp(36px,3.5vw,56px); font-weight:800; letter-spacing:-1.5px; line-height:1; color:var(--black); margin-bottom:8px; }
  .dev-role { font-size:13px; letter-spacing:3px; text-transform:uppercase; color:var(--accent); margin-bottom:32px; font-weight:600; }
  .dev-bio { font-size:16px; line-height:1.75; color:#444; max-width:520px; margin-bottom:48px; }
  .dev-stack-title { font-family:'Syne',sans-serif; font-size:11px; font-weight:700; letter-spacing:3px; text-transform:uppercase; color:#999; margin-bottom:18px; }
  .dev-skills { display:flex; flex-wrap:wrap; gap:10px; margin-bottom:48px; }
  .dev-skill { background:var(--black); color:var(--white); padding:9px 18px; font-family:'Syne',sans-serif; font-size:13px; font-weight:700; border-radius:2px; display:flex; align-items:center; gap:8px; }
  .skill-dot { width:6px; height:6px; border-radius:50%; background:var(--accent); }
  .dev-stats { display:grid; grid-template-columns:repeat(3,1fr); gap:2px; border-top:2px solid rgba(0,0,0,.08); padding-top:32px; }
  .dev-stat .val { font-family:'Syne',sans-serif; font-size:36px; font-weight:800; color:var(--black); line-height:1; }
  .dev-stat .val span { color:var(--accent); }
  .dev-stat .lbl { font-size:12px; letter-spacing:1.5px; text-transform:uppercase; color:#888; margin-top:4px; }

  /* PRICING */
  .pricing { background: var(--black); }
  .pricing-grid { margin-top:80px; display:grid; grid-template-columns:repeat(4,1fr); gap:2px; }
  .plan { background:var(--mid); border:1px solid var(--border); padding:40px 32px; position:relative; transition:transform .2s; }
  .plan:hover { transform:translateY(-6px); }
  .plan.featured { background:var(--accent); border-color:var(--accent); }
  .plan-badge { position:absolute; top:-1px; right:24px; background:var(--accent2); color:var(--black); font-family:'Syne',sans-serif; font-size:10px; font-weight:800; letter-spacing:2px; text-transform:uppercase; padding:6px 14px; }
  .plan.featured .plan-badge { background: var(--black); color: var(--white); }
  .plan-name { font-size:12px; letter-spacing:3px; text-transform:uppercase; color:rgba(245,242,236,.5); margin-bottom:16px; }
  .plan.featured .plan-name { color:rgba(255,255,255,.7); }
  .plan-price { font-family:'Syne',sans-serif; font-size:28px; font-weight:800; letter-spacing:-1px; margin-bottom:8px; line-height:1.1; }
  .plan-desc { font-size:13px; color:rgba(245,242,236,.4); margin-bottom:28px; }
  .plan.featured .plan-desc { color:rgba(255,255,255,.6); }
  .plan-features { list-style:none; display:flex; flex-direction:column; gap:10px; margin-bottom:32px; }
  .plan-features li { font-size:13px; color:rgba(245,242,236,.7); padding-left:18px; position:relative; line-height:1.4; }
  .plan-features li::before { content:'→'; position:absolute; left:0; color:var(--accent); font-size:11px; }
  .plan.featured .plan-features li { color:rgba(255,255,255,.85); }
  .plan.featured .plan-features li::before { color:rgba(255,255,255,.6); }
  .plan-btn { display:block; text-align:center; padding:12px; font-family:'Syne',sans-serif; font-weight:700; font-size:12px; letter-spacing:1.5px; text-transform:uppercase; border:1.5px solid rgba(255,255,255,.15); color:var(--white); border-radius:2px; transition:background .2s,border-color .2s; margin-top:auto; }
  .plan-btn:hover { background:rgba(255,255,255,.08); border-color:rgba(255,255,255,.3); }
  .plan.featured .plan-btn { background:var(--black); border-color:var(--black); }
  .plan.featured .plan-btn:hover { background:#1c1c1c; }

  /* TESTIMONIALS */
  .testimonials { background:var(--black); border-top:1px solid var(--border); }
  .testi-grid { margin-top:80px; display:grid; grid-template-columns:repeat(3,1fr); gap:2px; }
  .testi-card { background:var(--mid); border:1px solid var(--border); padding:40px; }
  .testi-quote { font-size:32px; color:var(--accent); font-family:'Syne',sans-serif; line-height:1; margin-bottom:20px; }
  .testi-text { font-size:15px; line-height:1.7; color:rgba(245,242,236,.7); margin-bottom:32px; }
  .testi-author { display:flex; align-items:center; gap:14px; }
  .testi-avatar { width:44px; height:44px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-family:'Syne',sans-serif; font-weight:800; font-size:16px; color:white; flex-shrink:0; }
  .testi-name { font-family:'Syne',sans-serif; font-weight:700; font-size:15px; }
  .testi-role { font-size:12px; color:rgba(245,242,236,.4); margin-top:2px; }

  /* CTA */
  .cta-section { background:var(--accent); padding:120px 48px; text-align:center; }
  .cta-title { font-family:'Syne',sans-serif; font-size:clamp(48px,6vw,96px); font-weight:800; letter-spacing:-2px; color:var(--white); max-width:800px; margin:0 auto 40px; line-height:1; }
  .cta-section p { color:rgba(255,255,255,.7); font-size:16px; margin-bottom:48px; }
  .btn-white { background:var(--white); color:var(--accent); padding:18px 48px; font-family:'Syne',sans-serif; font-weight:800; font-size:14px; letter-spacing:1.5px; text-transform:uppercase; border-radius:2px; display:inline-block; transition:background .2s,transform .2s; }
  .btn-white:hover { background:#ede9df; transform:translateY(-2px); }

  /* FOOTER */
  footer { background:#050505; padding:64px 48px 40px; border-top:1px solid var(--border); }
  .footer-top { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:64px; gap:40px; }
  .footer-brand p { margin-top:16px; max-width:280px; font-size:14px; color:rgba(245,242,236,.35); line-height:1.6; }
  .footer-cols { display:flex; gap:64px; flex-wrap:wrap; }
  .footer-links h4 { font-family:'Syne',sans-serif; font-size:11px; font-weight:700; letter-spacing:3px; text-transform:uppercase; color:rgba(245,242,236,.3); margin-bottom:20px; }
  .footer-links ul { list-style:none; display:flex; flex-direction:column; gap:10px; }
  .footer-links a { color:rgba(245,242,236,.5); font-size:14px; transition:color .2s; }
  .footer-links a:hover { color:var(--white); }
  .footer-bottom { border-top:1px solid var(--border); padding-top:32px; display:flex; justify-content:space-between; align-items:center; }
  .footer-bottom p { font-size:13px; color:rgba(245,242,236,.25); }
  .footer-flag { font-size:12px; color:rgba(245,242,236,.25); }

  /* REVEAL */
  :global(.reveal) { opacity:0; transform:translateY(40px); transition:opacity .8s,transform .8s; }
  :global(.reveal.visible) { opacity:1; transform:translateY(0); }

  @keyframes fadeUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
  @keyframes marquee { from{transform:translateX(0)} to{transform:translateX(-50%)} }

  /* RESPONSIVE */
  @media(max-width:1100px) { .pricing-grid { grid-template-columns:repeat(2,1fr); } }
  @media(max-width:900px) {
    nav { padding:20px 24px; }
    .nav-links { display:none; }
    section { padding:80px 24px; }
    .services-grid,.testi-grid { grid-template-columns:1fr; }
    .process-steps { grid-template-columns:1fr 1fr; }
    .services-header { flex-direction:column; }
    .hero { padding:0 24px 60px; }
    .hero-counter { display:none; }
    .dev-layout { grid-template-columns:1fr; gap:48px; }
    .dev-photo-wrap { max-width:320px; }
    .dev-stats { grid-template-columns:1fr 1fr; }
    footer { padding:48px 24px 32px; }
    .footer-top { flex-direction:column; }
    .cta-section { padding:80px 24px; }
    .pricing-grid { grid-template-columns:1fr; }
  }
  @media(max-width:600px) { .process-steps { grid-template-columns:1fr; } }
</style>
